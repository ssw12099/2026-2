import streamlit as st

st.title("🎪 축제 부스 길잡이")
st.write("우리 팀의 기능을 추가해 축제 부스 길잡이를 완성해 보세요.")