// 2주차 4번: 연결 표현을 이용한 리스트 구현
// 제공된 PDF의 기본 코드 및 main() 보존 / 구현할 함수만 TODO 처리
// TODO에 들어 있는 throw는 임시 표시이므로, 직접 구현할 때 삭제하세요.

class Node {

    String data;

    Node next;

    public Node(String data) {

         // TODO 01: Node() 직접 구현 (아래 throw 문장을 지우고 작성)
         throw new UnsupportedOperationException("TODO: Node()");

    }

}

class LinkedList {

    private Node head;

    private int size;

    public LinkedList() {

         // TODO 02: LinkedList() 직접 구현 (아래 throw 문장을 지우고 작성)
         throw new UnsupportedOperationException("TODO: LinkedList()");

    }

    public void addFirst(String s) {

         // TODO 03: addFirst() 직접 구현 (아래 throw 문장을 지우고 작성)
         throw new UnsupportedOperationException("TODO: addFirst()");

    }

    public void insert(String s, Node p) {

        // TODO 04: insert() 직접 구현 (아래 throw 문장을 지우고 작성)
        throw new UnsupportedOperationException("TODO: insert()");

    }

    public void delete(Node p) {

        // TODO 05: delete() 직접 구현 (아래 throw 문장을 지우고 작성)
        throw new UnsupportedOperationException("TODO: delete()");

    }

    public Node search(String s) {

        // TODO 06: search() 직접 구현 (아래 throw 문장을 지우고 작성)
        throw new UnsupportedOperationException("TODO: search()");

    }

    public void print() {
        // TODO 07: print() 직접 구현 (아래 throw 문장을 지우고 작성)
        throw new UnsupportedOperationException("TODO: print()");

    }

}

public class Main {

    public static void main(String[] args) {

        LinkedList list = new LinkedList();

        list.addFirst("C");

        list.addFirst("B");

        list.addFirst("A");

        list.print();

        Node n = list.search("B");

        list.insert("D", n);

        list.print();

        list.delete(n);

        list.print();

    }

}
