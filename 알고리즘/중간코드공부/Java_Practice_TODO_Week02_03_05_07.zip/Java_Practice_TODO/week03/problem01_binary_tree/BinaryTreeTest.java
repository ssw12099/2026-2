// 3주차 1번: 이진 트리의 기본 연산 구현
// 제공된 PDF의 기본 코드 및 main() 보존 / 구현할 함수만 TODO 처리
// TODO에 들어 있는 throw는 임시 표시이므로, 직접 구현할 때 삭제하세요.

class BTNode {

    String data;

    BTNode Lchild;

    BTNode Rchild;

    public BTNode() {

    }

    public BTNode(String dt) {

        data = dt;

        Lchild = null;

        Rchild = null;

    }

    public BTNode(BTNode lc, String dt, BTNode rc) {

         data = dt;

         Lchild = lc;

         Rchild = rc;

    }

}

class BinaryTree {

    BTNode root;

    public BinaryTree() {

         // TODO 01: BinaryTree() 직접 구현 (아래 throw 문장을 지우고 작성)
         throw new UnsupportedOperationException("TODO: BinaryTree()");

    }

    public BinaryTree(BinaryTree ltree, String data, BinaryTree rtree) {

         // TODO 02: BinaryTree() 직접 구현 (아래 throw 문장을 지우고 작성)
         throw new UnsupportedOperationException("TODO: BinaryTree()");

    }

    public boolean isEmpty() {

         // TODO 03: isEmpty() 직접 구현 (아래 throw 문장을 지우고 작성)
         throw new UnsupportedOperationException("TODO: isEmpty()");

    }

    public BinaryTree leftSubTree() {

         // TODO 04: leftSubTree() 직접 구현 (아래 throw 문장을 지우고 작성)
         throw new UnsupportedOperationException("TODO: leftSubTree()");

    }

    public BinaryTree rightSubTree() {

         // TODO 05: rightSubTree() 직접 구현 (아래 throw 문장을 지우고 작성)
         throw new UnsupportedOperationException("TODO: rightSubTree()");

    }

    public String rootData() {

         // TODO 06: rootData() 직접 구현 (아래 throw 문장을 지우고 작성)
         throw new UnsupportedOperationException("TODO: rootData()");

    }

    public int calculate() {

         // TODO 07: calculate() 직접 구현 (아래 throw 문장을 지우고 작성)
         throw new UnsupportedOperationException("TODO: calculate()");

    }

    private int theCalculate(BTNode t) {

         // TODO 08: theCalculate() 직접 구현 (아래 throw 문장을 지우고 작성)
         throw new UnsupportedOperationException("TODO: theCalculate()");

    }

    public int height() {

         // TODO 09: height() 직접 구현 (아래 throw 문장을 지우고 작성)
         throw new UnsupportedOperationException("TODO: height()");

    }

    private int theHeight(BTNode t) {

         // TODO 10: theHeight() 직접 구현 (아래 throw 문장을 지우고 작성)
         throw new UnsupportedOperationException("TODO: theHeight()");

    }

    public void print0() {

         // TODO 11: print0() 직접 구현 (아래 throw 문장을 지우고 작성)
         throw new UnsupportedOperationException("TODO: print0()");

    }

    private void print0(BTNode t) {

         // TODO 12: print0() 직접 구현 (아래 throw 문장을 지우고 작성)
         throw new UnsupportedOperationException("TODO: print0()");

    }

}

public class BinaryTreeTest {

    public static void main(String args[]) {

         BinaryTree btree;

         BinaryTree ltree;

         BinaryTree rtree;

         BinaryTree current;

         rtree = new BinaryTree(

                 new BinaryTree(), "1", new BinaryTree());

        ltree = new BinaryTree(

                 new BinaryTree(), "2", new BinaryTree());

        btree = new BinaryTree(ltree, "+", rtree);

        ltree = btree;

        rtree = new BinaryTree(

                 new BinaryTree(), "3", new BinaryTree());

        btree = new BinaryTree(ltree, "*", rtree);

        System.out.println("계산 결과 : " + btree.calculate());

        System.out.print("수식 출력 : ");

        btree.print0();

        System.out.println("트리의 높이 : " + btree.height());

    }

}
