// 5주차 1번: 이진 트리의 순회 및 복사 구현
// 제공된 PDF의 기본 코드 및 main() 보존 / 구현할 함수만 TODO 처리
// TODO에 들어 있는 throw는 임시 표시이므로, 직접 구현할 때 삭제하세요.

import java.util.Stack;
import java.util.Queue;
import java.util.LinkedList;

class BTNode {

    String data;

    BTNode Lchild;

    BTNode Rchild;

    public BTNode() {

    }

    public BTNode(String dt) {

        data = dt;

        Lchild = null;

         Rchild = null;

    }

    public BTNode(BTNode lc, String dt, BTNode rc) {

         data = dt;

         Lchild = lc;

         Rchild = rc;

    }

}

class BinaryTree {

    BTNode root;

    public BinaryTree() {

         root = null;

    }

    public BinaryTree(BinaryTree ltree, String data, BinaryTree rtree) {

         root = new BTNode(ltree.root, data, rtree.root);

    }

    public boolean isEmpty() {

         return root == null;

    }

    public BinaryTree leftSubTree() {

         BinaryTree ltree = new BinaryTree();

         ltree.root = root.Lchild;

         return ltree;

    }

    public BinaryTree rightSubTree() {

         BinaryTree rtree = new BinaryTree();

    rtree.root = root.Rchild;

    return rtree;

}

public String rootData() {

    return root.data;

}

public void inorder() {

    System.out.println();

    System.out.println("Inorder");

    theInorder(root);

    System.out.println();

    System.out.println("InorderIter");

    inorderIter1();

}

public void preorder() {

    System.out.println("preorder");

    System.out.println();

    thePreorder(root);

    System.out.println();

    System.out.println("preorderIter");

    preorderIter();

}

public void postorder() {

    thePostorder(root);

}

private void theInorder(BTNode t) {

    // TODO 01: theInorder() 직접 구현 (아래 throw 문장을 지우고 작성)
    throw new UnsupportedOperationException("TODO: theInorder()");

}

private void thePreorder(BTNode t) {

    // TODO 02: thePreorder() 직접 구현 (아래 throw 문장을 지우고 작성)
    throw new UnsupportedOperationException("TODO: thePreorder()");

}

private void thePostorder(BTNode t) {

    // TODO 03: thePostorder() 직접 구현 (아래 throw 문장을 지우고 작성)
    throw new UnsupportedOperationException("TODO: thePostorder()");

}

private void inorderIter1() {

    // TODO 04: inorderIter1() 직접 구현 (아래 throw 문장을 지우고 작성)
    throw new UnsupportedOperationException("TODO: inorderIter1()");

}

private void preorderIter() {

    // TODO 05: preorderIter() 직접 구현 (아래 throw 문장을 지우고 작성)
    throw new UnsupportedOperationException("TODO: preorderIter()");

}

public void levelorder() {

    // TODO 06: levelorder() 직접 구현 (아래 throw 문장을 지우고 작성)
    throw new UnsupportedOperationException("TODO: levelorder()");

}

public BinaryTree copy() {

    // TODO 07: copy() 직접 구현 (아래 throw 문장을 지우고 작성)
    throw new UnsupportedOperationException("TODO: copy()");

}

private BTNode theCopy(BTNode t) {

    // TODO 08: theCopy() 직접 구현 (아래 throw 문장을 지우고 작성)
    throw new UnsupportedOperationException("TODO: theCopy()");

}

public boolean equals(BinaryTree tr) {

    return theEqual(this.root, tr.root);

}

    private boolean theEqual(BTNode s, BTNode t) {

         // TODO 09: theEqual() 직접 구현 (아래 throw 문장을 지우고 작성)
         throw new UnsupportedOperationException("TODO: theEqual()");

    }

}

public class BinaryTreeTest {

    public static void main(String args[]) {

         BinaryTree btree;

         BinaryTree ltree;

         BinaryTree rtree;

         BinaryTree current;

         rtree = new BinaryTree(new BinaryTree(), "H", new BinaryTree());

         btree = new BinaryTree(new BinaryTree(), "G", rtree);

         ltree = btree;

         btree = new BinaryTree(ltree, "E", new BinaryTree());

         ltree = new BinaryTree(new BinaryTree(), "D", new BinaryTree());

         rtree = btree;

         btree = new BinaryTree(ltree, "B", rtree);

         ltree = new BinaryTree(new BinaryTree(), "F", new BinaryTree());

         current = new BinaryTree(ltree, "C", new BinaryTree());

         ltree = btree;

         rtree = current;

         btree = new BinaryTree(ltree, "A", rtree);

         System.out.println(btree.rootData());

         System.out.println(btree.leftSubTree().rootData());

         System.out.println(btree.rightSubTree().rootData());

         System.out.println(btree.leftSubTree().leftSubTree().rootData());

        System.out.println(btree.rightSubTree().leftSubTree().rootData());

        btree.inorder();

        System.out.println();

        btree.preorder();

        System.out.println();

        btree.postorder();

        System.out.println();

        btree.levelorder();

        System.out.println();

        current = btree.copy();

        current.inorder();

        System.out.println();

        if (btree.equals(current))

               System.out.println("They are the same trees");

        else

               System.out.println("They are different trees");

        if (btree.equals(ltree))

               System.out.println("They are the same trees");

        else

               System.out.println("They are different trees");

    }

}
